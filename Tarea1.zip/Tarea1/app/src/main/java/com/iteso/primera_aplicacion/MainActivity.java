package com.iteso.primera_aplicacion;

import android.app.Activity;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public class Alumno{
        EditText name, phone;
        Spinner spinner;
        RadioButton radiobutton;
        CheckBox checkbox;
        AutoCompleteTextView actv;

        public Alumno(AutoCompleteTextView actv,
                      Spinner spinner, RadioButton radiobutton,
                      EditText name, EditText phone, CheckBox checkbox) {
            this.name = name;
            this.phone = phone;
            this.spinner = spinner;
            this.radiobutton = radiobutton;
            this.actv = actv;
            this.checkbox = checkbox;
        }

        public String toString() {
            String str;
            str="Nombre: "+name.getText()+"\n"+ "Telefono: "+phone.getText()+"\n"+ "Escolaridad: "+spinner.getSelectedItem().toString()+"\n"+ "Genero : "+radiobutton.getText()+"\n";

            if(actv.getText().length()>0){
                str+="Libro favorito:" + actv.getText();
            }else{
                str+="\n";
            }

            str+="Practica Deporte:";
            if(checkbox.isChecked()){
                str+="si";
            }else{
                str+="no";
            }

            return str;

        }
    }

    EditText name, phone;
    Spinner spinner;
    RadioButton radiobutton;
    CheckBox checkbox;
    AutoCompleteTextView actv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.name);
        phone = findViewById(R.id.telefono);
        checkbox = findViewById(R.id.checkbox_sport);
        spinner = findViewById(R.id.spinner);
        radiobutton = findViewById(R.id.fem);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.escolaridad, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        actv = findViewById(R.id.autocomplete_libros);
        String[] libros = getResources().getStringArray(R.array.libros);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, libros);
        actv.setAdapter(adapter2);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity_main_menu, menu);
        return true;

    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.masc:
                if (checked)
                    radiobutton = findViewById(R.id.masc);
                break;
            case R.id.fem:
                if (checked)
                    radiobutton = findViewById(R.id.fem);
                break;
        }
    }


    public class SpinnerActivity extends Activity
            implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
        }
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        Alumno alumno = new Alumno(actv, spinner, radiobutton, name, phone, checkbox);
            Toast.makeText(this, alumno.toString(), Toast.LENGTH_LONG).show();
            limpiar();
        return true;
    }



    public void onButtonClicked(View view) {
        android.support.v7.app.AlertDialog.Builder dialog = new android.support.v7.app.AlertDialog.Builder(this);
        dialog.setMessage("Desea limpiar el contenido?");
        dialog.setNegativeButton("cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                limpiar();
            }
        });

        dialog.create();
        dialog.show();
    }



    public void limpiar() {
        name.setText("");
        phone.setText("");
        checkbox.setChecked(false);
        radiobutton = findViewById(R.id.fem);
        radiobutton.setChecked(true);
        spinner.setSelection(0);
        actv.setText("");
        actv.setText("");
    }




}

